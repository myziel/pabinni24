<?php
class ControllerProductAllsellers extends Controller {
	public function index() {
		$this->load->language('catalog/seller');
		$this->document->setTitle('All sellers');
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$data['breadcrumbs'][] = array(
			'text' => 'product',
			'href' => $this->url->link('product/product', '', 'SSL')
		);
		$data['breadcrumbs'][] = array(
			'text' => 'all sellers',
			'href' => $this->url->link('product/all_sellers', '', 'SSL')
		);
		$this->load->model('catalog/seller');
		$data['heading_title'] = $this->language->get('heading_title');
		$data['column_date_added'] = $this->language->get('column_date_added');
		$data['column_description'] = $this->language->get('column_description');
		$data['column_amount'] = sprintf($this->language->get('column_amount'), $this->config->get('config_currency'));
		$data['text_total'] = $this->language->get('text_total');
		$data['text_empty'] = $this->language->get('text_empty');
		$data['button_continue'] = $this->language->get('button_continue');

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
        $data['vendor_login_link']=$this->getBaseUrl."seller";
		$data['all_sellers'] = array();

		$filter_data = array(
			'sort'  => 'date_added',
			'order' => 'DESC',
			'start' => ($page - 1) * 10,
			'limit' => 10
		);

		$this->load->model('tool/image');
		$all_sellers_total = $this->model_catalog_seller->gettotalseller();

		$results = $this->model_catalog_seller->getSellers();

		foreach ($results as $result) {
		
		
		if (!empty($result) && $result['image'] && file_exists(DIR_IMAGE . $result['image'])) {
					$image = $this->model_tool_image->resize($result['image'], 100, 100);
					} else {
					$image = $this->model_tool_image->resize('avatar.png', 100, 100);
					}
		
		
			$data['all_sellers'][] = array(
				'seller_id'      => $result['seller_id'],
				'name' => $result['name'],
				'thumb' => $image,
				'href'        => $this->url->link('product/seller', 'seller_id='.$result['seller_id'],'','SSL'),
				'date_added'  => date($this->language->get('date_format_short'), strtotime($result['date_added'])),
				'approved'    => $result['approved']
			);
		}
		$pagination = new Pagination();
		$pagination->total = $all_sellers_total;
		$pagination->page = $page;
		$pagination->limit = 10;
		$pagination->url = $this->url->link('product/all_sellers', 'page={page}', 'SSL');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($all_sellers_total) ? (($page - 1) * 10) + 1 : 0, ((($page - 1) * 10) > ($all_sellers_total - 10)) ? $all_sellers_total : ((($page - 1) * 10) + 10), $all_sellers_total, ceil($all_sellers_total / 10));

//		$data['total'] = $this->currency->format($this->customer->getBalance());

		$data['continue'] = $this->url->link('common/home', '', 'SSL');

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/product/all_sellers.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/product/all_sellers.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('product/all_sellers.tpl', $data));
		}
	}
}