<?php
class ControllerAccountAutonetbalancing extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/account', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$this->load->model('account/binarysystem');
		$this->load->model('account/customer');
        $customer_id = $this->customer->getId();
        $customerdetail=$this->model_account_customer->getCustomer($customer_id);
		
        $mlm_settings=$this->model_account_binarysystem->get_binarysystem_settings();
        $autonetbalancingsetting=$this->model_account_binarysystem->get_autonetbalancing_settings();
        
        if(!empty($autonetbalancingsetting)){
            $targetpoint=$autonetbalancingsetting['division_points'];
        }else{
            $targetpoint=0;
        }
//        if($customerdetail['cp_points']>=$mlm_settings['eligibility_cp']){
            
        
        if(isset($mlm_settings['maximum_level']) && $mlm_settings['maximum_level']!='' && $mlm_settings['maximum_level']!=0){
            $maximum_level=$mlm_settings['maximum_level'];
        }else{
            $maximum_level=0;
        }
        $qualifiedcustomers=$this->model_account_binarysystem->get_qualified_customers($customer_id);
        
        $startpoint=0;
        $endpoint=0;
        $i=0;
        $k=0;
        $parsedarray=array();
//        echo "<pre>";
//        var_dump($qualifiedcustomers);
//        exit;
        while($i<sizeof($qualifiedcustomers)){
            if($i==0){
                $parsedarray[]=array(0=>$qualifiedcustomers[$i]);
                $i++;
                $k++;
                $startpoint=$i;
            }else{
                $numberofelements=$k*2;
                $subarray=array();
                for($j=1;$j<=$numberofelements;$j++){
                    if(isset($qualifiedcustomers[$startpoint])){
                        
                        $subarray[]=$qualifiedcustomers[$startpoint];
                    }
                    else{
                        break;
                    }
                    $i++;
                    $startpoint=$i;
                }
                $k++;
                $parsedarray[]=$subarray;
            }
        }
        $binarytree=array();
        $leftchilds=array();
        $rightchilds=array();
        for($n=0;$n<sizeof($parsedarray);$n++){
            $innerflag=0;
            for($v=0;$v<sizeof($parsedarray[$n]);$v++){
                $autonetid=$parsedarray[$n][$v]['id'];
                $customerdetail=$this->model_account_customer->getCustomer($parsedarray[$n][$v]['customer_id']);
                if($n==0){
                    $binarytree[]=array('id'=>$parsedarray[$n][$v]['customer_id'],'autonet_id'=>$parsedarray[$n][$v]['id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>"CP Points: ".$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'autonet_id' => 'Autonet ID: '.$parsedarray[$n][$v]['id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'text_qualifyingdate' => 'Qualifying Date: '.date('d-M-Y h:i A',strtotime($parsedarray[$n][$v]['created_date'])), 'father'=>null, 'color'=>'#16c9e5');
                }else{
                        $fixedindex=$n-1;
                        $parentindex=(int)($v/2);
                        $binarytree[]=array('id'=>$parsedarray[$n][$v]['customer_id'],'autonet_id'=>$parsedarray[$n][$v]['id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>"CP Points: ".$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'autonet_id' => 'Autonet ID: '.$parsedarray[$n][$v]['id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'text_qualifyingdate' => 'Qualifying Date: '.date('d-M-Y h:i A',strtotime($parsedarray[$n][$v]['created_date'])), 'father'=>$parsedarray[$fixedindex][$parentindex]['customer_id'], 'color'=>'#16c9e5');
                        if($customer_id==$parsedarray[$fixedindex][$parentindex]['customer_id']){
                            if(empty($leftchilds)){
                                $leftchilds[]=$parsedarray[$n][$v]['customer_id'];
                            }else if(empty($rightchilds)){
                                $rightchilds[]=$parsedarray[$n][$v]['customer_id'];
                            }
                        }
                    
                }
            }
        }
        if((sizeof($binarytree)%2==0) && (!empty($binarytree))){
            $binarytree[sizeof($binarytree)]=array('id'=>0,'autonet_id'=>0, 'text_1'=>'', 'text_2'=>'', 'text_id' => '', 'autonet_id' => '', 'text_qualifyingdate' => '', 'text_joiningdate' => '', 'father'=>$binarytree[sizeof($binarytree)-1]['father'], 'color'=>'#16c9e5');
        }
        
        
        foreach($binarytree as $tree){
            if($tree['id']!=0){
                if (in_array($tree['father'], $leftchilds)){
                    $leftchilds[]=$tree['id'];
                }elseif(in_array($tree['father'], $rightchilds)){
                    $rightchilds[]=$tree['id'];
                }
            }
            
        }
        $leftsidelength=$this->findheight($leftchilds);
        $rightsidelength=$this->findheight($rightchilds);
        $steps=0;
//        echo sizeof($leftchilds)." ".sizeof($rightchilds);
//        exit;
//        if(sizeof($leftchilds)<=sizeof($rightchilds)){
//            $steps=sizeof($leftchilds);
//        }else{
//            $steps=sizeof($rightchilds);
//        }
        if($leftsidelength<=$rightsidelength){
            $steps=$leftsidelength;
        }
        else{
            $steps=$rightsidelength;
        }
        $autonetbonussteps=$this->model_account_binarysystem->get_autonetbalancing_bonus_steps();
        $calculatedsteps=0;
        $autonetbalancingbonus=0;
        foreach($autonetbonussteps as $step){
            $calculatedsteps=$calculatedsteps+$step['steps'];
            if($calculatedsteps<=$steps){
                $autonetbalancingbonus=$autonetbalancingbonus+$step['bonus_amount'];
            }
        }
//        $bonusvalues=$this->model_account_binarysystem->get_autonetbalancing_bonus_againststeps($steps);
//        if(isset($bonusvalues['bonusamount']) && $bonusvalues['bonusamount']!=null){
//            $autonetbalancingbonus=$bonusvalues['bonusamount'];
//        }
        $data['autonetbalancingbonus']=$autonetbalancingbonus;
        $data['plugin_tree_data']=$binarytree;
        
//        $data['leadershipbonus']=$leadershipbonus;
        $data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/autonetbalancing', $data));
	}
    public function calculate_left_points($childsarray,$targetpoint){
       
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        
        if($customerdetail['cp_points']>=$divisionby){
            
            $calculatedval=(int)($customerdetail['cp_points']/$divisionby);
            $GLOBALS['left_points']=$GLOBALS['left_points']+$calculatedval;
        }
        if(!empty($childsarray['childs'])){
            foreach($childsarray['childs'] as $child){
                return $this->calculate_left_points($child,$targetpoint);
            }
        }
        
            return $GLOBALS['left_points'];
    }
    
    public function calculate_right_points($childsarray,$targetpoint){
        
//        if($GLOBALS['right_points']>=$levelpoints){
//            echo "in if";
//            exit;
//            return $GLOBALS['right_points'];
//        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        
        if($customerdetail['cp_points']>=$divisionby){
            
            $calculatedval=(int)($customerdetail['cp_points']/$divisionby);
            
            $GLOBALS['right_points']=$GLOBALS['right_points']+$calculatedval;
        }
        if(!empty($childsarray['childs'])){

            foreach($childsarray['childs'] as $child){
                return $this->calculate_right_points($child,$targetpoint);
            }
        }
        return $GLOBALS['right_points'];
    }
    public function findheight($leftchilds){
        $numberofnodes=sizeof($leftchilds);
        
        $remainingnodes=$numberofnodes;
        $depth=0;
        for($i=1;$i<=$numberofnodes;$i=($i*2)){
            $depth++;
            $remainingnodes=$remainingnodes-$i;
        }
        return $depth;
    }
}
