<?php
class ControllerAccountLevelsystem extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/account', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
        
		$this->load->model('account/levelsystem');
		$this->load->model('account/customer');
        $this->load->model('account/binarysystem');
        $customer_id = $this->customer->getId();
        $customerdetail=$this->model_account_customer->getCustomer($customer_id);
		
        $mlm_settings=$this->model_account_levelsystem->get_levelsystem_settings();
        $systempercentages=$this->model_account_levelsystem->get_system_percentages();
        
        if(isset($mlm_settings['maximum_level']) && $mlm_settings['maximum_level']!='' && $mlm_settings['maximum_level']!=0){
            $maximum_level=$mlm_settings['maximum_level'];
            
        }else{
            $maximum_level=5;
        }
        $allowedlevels=0;
        if($mlm_settings['level_unlock_points'] && $mlm_settings['level_unlock_points']!=''){
            $unlocklevels=unserialize($mlm_settings['level_unlock_points']);
            for($i=0;$i<sizeof($unlocklevels);$i++){
                if(isset($unlocklevels[$i+1])){
                    if($customerdetail['cp_points']>=$unlocklevels[$i] && $customerdetail['cp_points']<$unlocklevels[$i+1]){
                        $allowedlevels=$i+1;
                    }
                }
                else{
                    if($customerdetail['cp_points']>=$unlocklevels[$i]){
                        $allowedlevels=$i+1;
                    }
                }
//                elseif($allowedlevels==0){
//                    $allowedlevels=$i+1;
//                }
                
            }
        }else{
            $allowedlevels=0;
        }
        $levelspercentage=array();
        if(isset($mlm_settings['level_percentage']) && $mlm_settings['level_percentage']!=''){
            $percentages=unserialize($mlm_settings['level_percentage']);
            $flag=0;
            foreach($percentages as $percentage){
                $flag++;
                $levelspercentage[$flag]=$percentage;
            }
        }
        $GLOBALS['total_cp_points_by_level']=array();
        $GLOBALS['numberof_account_by_level']=array();
        $GLOBALS['tree_data_levelsystem'][]=array('id'=>$customer_id, 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>null, 'color'=>'#16c9e5');
        $GLOBALS["total_cp_points_levelsystem"]=0;
        $levelsytems=$this->get_first_level($customer_id,'parentcall',1,$allowedlevels,$levelspercentage,$systempercentages);
        
//        echo "<pre>".$GLOBALS["total_cp_points_levelsystem"];
//        var_dump($GLOBALS['tree_data_levelsystem']);
//        var_dump($levelsytems);
//        var_dump($customerdetail);
//        exit;
        
        $parentpersonal_points=calculate_personal_points($customerdetail['cp_points'],$systempercentages['customer_expense'],$systempercentages['personal_points']);
        
        $cppoint_value_indollar=$this->model_account_binarysystem->get_cppoint_value_indollar();
        if(!empty($cppoint_value_indollar)){
            $cppoint_value_indollar=$cppoint_value_indollar['value'];
        }else{
            $cppoint_value_indollar=0;
        }
//        echo $GLOBALS["total_cp_points_levelsystem"];
//        exit;
        $data['configuration_cp_amount']=$this->config->get('cp_point_amount');
        $data['parentpersonal_points']=$parentpersonal_points;
        $data['plugin_tree_data']=$GLOBALS['tree_data_levelsystem'];
        $data['total_cp_points']=$GLOBALS["total_cp_points_levelsystem"]*$cppoint_value_indollar;
        $data['numberof_account_by_level']=$GLOBALS['numberof_account_by_level'];
        $data['points_bylevel']=$GLOBALS['total_cp_points_by_level'];
        $data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/levelsystem', $data));
	}
    public function get_first_level($customerid,$calltype=null,$callnumber,$maximum_level,$levelspercentage,$systempercentages){
        
//        echo $callnumber;
        $firstlevel=$this->model_account_levelsystem->get_first_level($customerid);
        $mainarray=array();
        if(!empty($firstlevel) && $firstlevel['first_levels']!=''){
        $firstlevel=explode(',', $firstlevel['first_levels']);
        
        $subchildrens=array();
        $tree_plugindata=array();
        foreach($firstlevel as $id){
            $customerdetail=$this->model_account_customer->getCustomer($id);
//            $GLOBALS['total_cp_points_levelsystem']=$GLOBALS['total_cp_points_levelsystem']+(($customerdetail['cp_points']*$levelspercentage[$callnumber])/100);
//            echo "<pre>".$callnumber;
//            var_dump($customerdetail);
            if(isset($GLOBALS['total_cp_points_by_level'][$callnumber])){
                $customer_percentage_points=calculate_customer_points_by_level($customerdetail['cp_points'],$levelspercentage[$callnumber],$systempercentages['customer_expense'],$systempercentages['level_system']);
                
                if($callnumber <= $maximum_level){
                    $GLOBALS['total_cp_points_by_level'][$callnumber]=$GLOBALS['total_cp_points_by_level'][$callnumber]+$customer_percentage_points;
                    $GLOBALS['numberof_account_by_level'][$callnumber]=$GLOBALS['numberof_account_by_level'][$callnumber]+1;
                    $GLOBALS['total_cp_points_levelsystem']=$GLOBALS['total_cp_points_levelsystem']+$customer_percentage_points;
                }
                
            }else{
                $customer_percentage_points=calculate_customer_points_by_level($customerdetail['cp_points'],$levelspercentage[$callnumber],$systempercentages['customer_expense'],$systempercentages['level_system']);
                
                if($callnumber <= $maximum_level){
                    $GLOBALS['numberof_account_by_level'][$callnumber]=1;
                    $GLOBALS['total_cp_points_by_level'][$callnumber]=$customer_percentage_points;
                    $GLOBALS['total_cp_points_levelsystem']=$GLOBALS['total_cp_points_levelsystem']+$customer_percentage_points;
                }
                
            }
            
            if($callnumber<$maximum_level){
                $sub_childs=$this->get_first_level($id,"",$callnumber+1,$maximum_level,$levelspercentage,$systempercentages);
            }else{
                $sub_childs=array();
            }
            
            $subchildrens[]=array('id'=>$id, 'childs'=>$sub_childs);
//            $tree_plugindata[]=array('id'=>$id, 'text_1'=>'Fname', 'text_2'=>'Lname', 'father'=>$customerdetail['referral_id'], 'color'=>'#000');
            $GLOBALS['tree_data_levelsystem'][]=array('id'=>$id, 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>$customerdetail['referral_id'], 'color'=>'#16c9e5');
            
            
        }
//            echo "<pre>";
//            echo $callnumber;
//            var_dump($tree_plugindata);
//            echo $callnumber+1;
//            $GLOBALS['tree_data_levelsystem']=$tree_plugindata;
//            var_dump($GLOBALS['tree_data_levelsystem_'.$callnumber+1]);
//            exit;
        $mainarray=$subchildrens;
        }
        return $mainarray;
    }
    
}
