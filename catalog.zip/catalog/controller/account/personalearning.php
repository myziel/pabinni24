<?php
class ControllerAccountPersonalearning extends Controller {
    private $error = array();
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/account', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);
        
		$this->load->model('account/levelsystem');
		$this->load->model('account/binarysystem');
		$this->load->model('account/customer');
        $customer_id = $this->customer->getId();
        
        $customerdetail=$this->model_account_customer->getCustomer($customer_id);
        $logincustomerdetail=$customerdetail;
        /* Withdrawal Code Start */
        
        if($this->submitwithdrawal($customerdetail)){
            if($this->request->post['withdrawal_type']=='ewallet'){
                $this->session->data['success']="Your amount $".$this->request->post['withdrawal_amount']." is successfully transfered to your E-Wallet.";
            }
            else{
                $this->session->data['success']="Your withdrawal request has been received and will be approved by admin after checking the details.";
            }
            $this->response->redirect('index.php?route=account/personalearning');
        }
        if(isset($this->request->post['withdrawal_amount'])){
            $data['withdrwal_amount_ewallet']=$this->request->post['withdrawal_amount'];
        }
        else{
            $data['withdrwal_amount_ewallet']='';
        }
        if(isset($this->request->post['withdrawal_type'])){
            $data['withdrawal_type']=$this->request->post['withdrawal_type'];
        }
        else{
            $data['withdrawal_type']='';
        }
        if (isset($this->error['withdrawal_error'])) {
			$data['withdrawal_error'] = $this->error['withdrawal_error'];
		} else {
			$data['withdrawal_error'] = '';
		}
        if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
        
        /* Withdrawal Code End */
        
		$parentpersonalpoints=$customerdetail['cp_points'];
        $mlm_settings=$this->model_account_levelsystem->get_levelsystem_settings();
        $systempercentages=$this->model_account_levelsystem->get_system_percentages();
        
        if(isset($mlm_settings['maximum_level']) && $mlm_settings['maximum_level']!='' && $mlm_settings['maximum_level']!=0){
            $maximum_level=$mlm_settings['maximum_level'];
        }else{
            $maximum_level=5;
        }
        $allowedlevels=0;
        if($mlm_settings['level_unlock_points'] && $mlm_settings['level_unlock_points']!=''){
            $unlocklevels=unserialize($mlm_settings['level_unlock_points']);
            for($i=0;$i<sizeof($unlocklevels);$i++){
                if(isset($unlocklevels[$i+1])){
                    if($customerdetail['cp_points']>=$unlocklevels[$i] && $customerdetail['cp_points']<$unlocklevels[$i+1]){
                        $allowedlevels=$i+1;
                    }
                }
                else{
                    if($customerdetail['cp_points']>=$unlocklevels[$i]){
                        $allowedlevels=$i+1;
                    }
                }
//                elseif($allowedlevels==0){
//                    $allowedlevels=$i+1;
//                }
                
            }
        }else{
            $allowedlevels=0;
        }
        $levelspercentage=array();
        if(isset($mlm_settings['level_percentage']) && $mlm_settings['level_percentage']!=''){
            $percentages=unserialize($mlm_settings['level_percentage']);
            $flag=0;
            foreach($percentages as $percentage){
                $flag++;
                $levelspercentage[$flag]=$percentage;
            }
        }
        $GLOBALS['total_cp_points_by_level']=array();
        $GLOBALS['tree_data_levelsystem'][]=array('id'=>$customer_id, 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>null, 'color'=>'#16c9e5');
        $GLOBALS["total_cp_points_levelsystem"]=0;
        $levelsytems=$this->get_first_level($customer_id,'parentcall',1,$allowedlevels,$levelspercentage,$systempercentages);
        
        
        
        /*Binary Calculations start*/
        
        $binary_settings=$this->model_account_binarysystem->get_binarysystem_settings();
        $binarysystem=$this->get_binary_childrens($customer_id,1,$maximum_level);
        $calculateuptolevelsbinary=0;
        $levelpoints=0;
        if($binary_settings['level_points'] && $binary_settings['level_points']!=''){
            $unlocklevels=unserialize($binary_settings['level_points']);
            $temppreviouspoints=0;
            for($i=1;$i<=sizeof($unlocklevels);$i++){
                if(isset($unlocklevels[$i])){
                    if($customerdetail['cp_points']>=$unlocklevels[$i]['eligibility_level_points'] && $customerdetail['cp_points']>$temppreviouspoints){
                        $levelpoints=$unlocklevels[$i]['eligibility_steps'];
                        $calculateuptolevelsbinary=$unlocklevels[$i]['calculated_steps'];
//                        $divisiblepoints=$unlocklevels[$i]['eligibility_level_points'];
                        $temppreviouspoints=$unlocklevels[$i]['eligibility_level_points'];
                    }
                }
                
            }
        }else{
            $levelpoints=0;
        }
        
        
        $divisiblepoints=$binary_settings['eligibility_cp'];
        $GLOBALS['left_points']=0;
        if(isset($binarysystem[0])){
            $GLOBALS['left_points']=$this->calculate_left_points($binarysystem[0],$levelpoints,$customerdetail['cp_points'],$divisiblepoints,$calculateuptolevelsbinary);
        }
        $GLOBALS['right_points']=0;
        if(isset($binarysystem[1])){
            $GLOBALS['right_points']=$this->calculate_right_points($binarysystem[1],$levelpoints,$customerdetail['cp_points'],$divisiblepoints,$calculateuptolevelsbinary);
        }
        if($GLOBALS['right_points']>=$levelpoints){
            $GLOBALS['right_points']=$levelpoints;
        }
        if($GLOBALS['left_points']>=$levelpoints){
            $GLOBALS['left_points']=$levelpoints;
        }
        if($GLOBALS['left_points']<$GLOBALS['right_points']){
            $totalcppoints=$binary_settings['step_value']*$GLOBALS['left_points'];
        }
        else{
            $totalcppoints=$binary_settings['step_value']*$GLOBALS['right_points'];
        }
       
        /*Binary Calculations end*/
        
        
        
        /*Leadership Calculations start*/
        
        
        $leadership_settings=$this->model_account_binarysystem->get_binarysystem_settings();
        $leadershipsetting=$this->model_account_binarysystem->get_leaderaship_settings();
        $leadershipsteps=$this->model_account_binarysystem->get_leaderaship_steps();
        if($customerdetail['cp_points']<$leadershipsetting['eligibility_cp']){
            $data['eligibilty_error']="You are not eligible for leadership bonus.";
        }
        
        if(!empty($leadershipsetting)){
            $divisionby=$leadershipsetting['division_points'];
            $calculateuptolevels=$leadershipsetting['depth_level'];
        }else{
            $divisionby=0;
            $calculateuptolevels=0;
        }
        if(isset($binary_settings['maximum_level']) && $binary_settings['maximum_level']!='' && $binary_settings['maximum_level']!=0){
            $maximum_level=$binary_settings['maximum_level'];
        }else{
            $maximum_level=0;
        }
        $GLOBALS['tree_data_binarysystem'][]=array('id'=>$customerdetail['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>null, 'color'=>'#16c9e5');
        $binarysystem=$this->get_binary_childrens($customer_id,1,$maximum_level);
        
        
        
        $GLOBALS['left_points']=0;
        if(isset($binarysystem[0])){
            $GLOBALS['left_points']=$this->calculate_left_points_leadership($binarysystem[0],$divisionby, $calculateuptolevels);
        }
        $GLOBALS['right_points']=0;
        if(isset($binarysystem[1])){
            $GLOBALS['right_points']=$this->calculate_right_points_leadership($binarysystem[1],$divisionby, $calculateuptolevels);
        }
        if($GLOBALS['left_points']<=$GLOBALS['right_points']){
            $awarded_steps=$GLOBALS['left_points'];
        }
        else{
            $awarded_steps=$GLOBALS['right_points'];
        }
        
        $globalbonusvalues=0;
        $globalsteps=0;
        foreach($leadershipsteps as $step){
            $globalsteps=$globalsteps+$step['steps'];
            if($globalsteps<=$awarded_steps){
                $globalbonusvalues=$globalbonusvalues+$step['bonus_amount'];
            }
        }
//        $bonusvalues=$this->model_account_binarysystem->get_leaderaship_bonus_againststeps($awarded_steps);
//        $leadershipbonus=0;
//        if(isset($bonusvalues['bonusamount']) && $bonusvalues['bonusamount']!=null){
//            $leadershipbonus=$bonusvalues['bonusamount'];
//        }
        
        /*Leadership Calculations end*/
        
        
        
        
        
        /*Autonet Calculations start*/
        
        $autonetbalancingsetting=$this->model_account_binarysystem->get_autonetbalancing_settings();
        
        if(!empty($autonetbalancingsetting)){
            $targetpoint=$autonetbalancingsetting['division_points'];
        }else{
            $targetpoint=0;
        }
        if(isset($binary_settings['maximum_level']) && $binary_settings['maximum_level']!='' && $binary_settings['maximum_level']!=0){
            $maximum_level=$binary_settings['maximum_level'];
        }else{
            $maximum_level=0;
        }
        $qualifiedcustomers=$this->model_account_binarysystem->get_qualified_customers($customer_id);
        
        $startpoint=0;
        $endpoint=0;
        $i=0;
        $k=0;
        $parsedarray=array();
        while($i<sizeof($qualifiedcustomers)){
            if($i==0){
                $parsedarray[]=array(0=>$qualifiedcustomers[$i]);
                $i++;
                $k++;
                $startpoint=$i;
            }else{
                $numberofelements=$k*2;
                $subarray=array();
                for($j=1;$j<=$numberofelements;$j++){
                    if(isset($qualifiedcustomers[$startpoint])){
                        
                        $subarray[]=$qualifiedcustomers[$startpoint];
                    }
                    else{
                        break;
                    }
                    $i++;
                    $startpoint=$i;
                }
                $k++;
                $parsedarray[]=$subarray;
            }
        }
        
        $binarytree=array();
        $leftchilds=array();
        $rightchilds=array();
        for($n=0;$n<sizeof($parsedarray);$n++){
            $innerflag=0;
            for($v=0;$v<sizeof($parsedarray[$n]);$v++){
                $customerdetail=$this->model_account_customer->getCustomer($parsedarray[$n][$v]['customer_id']);
                if($n==0){
                    $binarytree[]=array('id'=>$parsedarray[$n][$v]['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>"CP Points: ".$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'text_qualifyingdate' => 'Qualifying Date: '.date('d-M-Y',strtotime($parsedarray[$n][$v]['created_date'])), 'father'=>null, 'color'=>'#16c9e5');
                }else{
                        $fixedindex=$n-1;
                        $parentindex=(int)($v/2);
                        $binarytree[]=array('id'=>$parsedarray[$n][$v]['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>"CP Points: ".$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'text_qualifyingdate' => 'Qualifying Date: '.date('d-M-Y',strtotime($parsedarray[$n][$v]['created_date'])), 'father'=>$parsedarray[$fixedindex][$parentindex]['customer_id'], 'color'=>'#16c9e5');
                        if($customer_id==$parsedarray[$fixedindex][$parentindex]['customer_id']){
                            if(empty($leftchilds)){
                                $leftchilds[]=$parsedarray[$n][$v]['customer_id'];
                            }else if(empty($rightchilds)){
                                $rightchilds[]=$parsedarray[$n][$v]['customer_id'];
                            }
                        }
                    
                }
            }
        }
        
        if((sizeof($binarytree)%2==0) && (!empty($binarytree))){
            $binarytree[sizeof($binarytree)]=array('id'=>0,'autonet_id'=>0, 'text_1'=>'', 'text_2'=>'', 'text_id' => '', 'autonet_id' => '', 'text_qualifyingdate' => '', 'text_joiningdate' => '', 'father'=>$binarytree[sizeof($binarytree)-1]['father'], 'color'=>'#16c9e5');
        }
        foreach($binarytree as $tree){
            if($tree['id']!=0){
                if (in_array($tree['father'], $leftchilds)){
                    $leftchilds[]=$tree['id'];
                }elseif(in_array($tree['father'], $rightchilds)){
                    $rightchilds[]=$tree['id'];
                }
            }
            
        }
        $leftsidelength=$this->findheight($leftchilds);
        $rightsidelength=$this->findheight($rightchilds);
        $steps=0;
        if($leftsidelength<=$rightsidelength){
            $steps=$leftsidelength;
        }
        else{
            $steps=$rightsidelength;
        }
        $autonetbonussteps=$this->model_account_binarysystem->get_autonetbalancing_bonus_steps();
        $calculatedsteps=0;
        $autonetbalancingbonus=0;
        foreach($autonetbonussteps as $step){
            $calculatedsteps=$calculatedsteps+$step['steps'];
            if($calculatedsteps<=$steps){
                $autonetbalancingbonus=$autonetbalancingbonus+$step['bonus_amount'];
            }
        }
        
        /*Autonet Calculations end*/
        
        
        $cppoint_value_indollar=$this->model_account_binarysystem->get_cppoint_value_indollar();
        if(!empty($cppoint_value_indollar)){
            $cppoint_value_indollar=$cppoint_value_indollar['value'];
        }else{
            $cppoint_value_indollar=0;
        }
       
       $parentpersonal_points=calculate_personal_points($parentpersonalpoints,$systempercentages['customer_expense'],$systempercentages['personal_points']);
        
        $data['binary_total_cp_points']=$totalcppoints;
        $data['leadershipbonus']=$globalbonusvalues;
        $data['autonetbonus']=$autonetbalancingbonus;
        $data['parentpersonal_points']=$parentpersonal_points*$cppoint_value_indollar;
        $data['levelsystem_total_cp_points']=$GLOBALS["total_cp_points_levelsystem"]*$cppoint_value_indollar;
        $data['total_amount']=$data['levelsystem_total_cp_points']+$data['parentpersonal_points']+$data['autonetbonus']+$data['leadershipbonus']+$data['binary_total_cp_points'];
        $this->model_account_customer->update_total_earning($data['total_amount'],$customer_id);
        $data['withdrawal_amount']=$logincustomerdetail['withdrawal_amount'];
        $data['availabale_for_withdrawal']=$data['total_amount']-$logincustomerdetail['withdrawal_amount'];
        $data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/personalearning', $data));
	}
    public function get_first_level($customerid,$calltype=null,$callnumber,$maximum_level,$levelspercentage,$systempercentages){
        
//        echo $callnumber;
        $firstlevel=$this->model_account_levelsystem->get_first_level($customerid);
        $mainarray=array();
        if(!empty($firstlevel) && $firstlevel['first_levels']!=''){
        $firstlevel=explode(',', $firstlevel['first_levels']);
        
        $subchildrens=array();
        $tree_plugindata=array();
        foreach($firstlevel as $id){
            $customerdetail=$this->model_account_customer->getCustomer($id);
//            $GLOBALS['total_cp_points_levelsystem']=$GLOBALS['total_cp_points_levelsystem']+(($customerdetail['cp_points']*$levelspercentage[$callnumber])/100);
//            echo "<pre>".$callnumber;
//            var_dump($customerdetail);
            if(isset($GLOBALS['total_cp_points_by_level'][$callnumber])){
                $customer_percentage_points=calculate_customer_points_by_level($customerdetail['cp_points'],$levelspercentage[$callnumber],$systempercentages['customer_expense'],$systempercentages['level_system']);
                if($callnumber <= $maximum_level){
                    $GLOBALS['total_cp_points_by_level'][$callnumber]=$GLOBALS['total_cp_points_by_level'][$callnumber]+$customer_percentage_points;
                $GLOBALS['numberof_account_by_level'][$callnumber]=$GLOBALS['numberof_account_by_level'][$callnumber]+1;
                $GLOBALS['total_cp_points_levelsystem']=$GLOBALS['total_cp_points_levelsystem']+$customer_percentage_points;
                }
                
                
            }else{
                $customer_percentage_points=calculate_customer_points_by_level($customerdetail['cp_points'],$levelspercentage[$callnumber],$systempercentages['customer_expense'],$systempercentages['level_system']);
                if($callnumber <= $maximum_level){
                    $GLOBALS['numberof_account_by_level'][$callnumber]=1;
                    $GLOBALS['total_cp_points_by_level'][$callnumber]=$customer_percentage_points;
                    $GLOBALS['total_cp_points_levelsystem']=$GLOBALS['total_cp_points_levelsystem']+$customer_percentage_points;
                }
                
            }
            
            if($callnumber<$maximum_level){
                $sub_childs=$this->get_first_level($id,"",$callnumber+1,$maximum_level,$levelspercentage,$systempercentages);
            }else{
                $sub_childs=array();
            }
            
            $subchildrens[]=array('id'=>$id, 'childs'=>$sub_childs);
//            $tree_plugindata[]=array('id'=>$id, 'text_1'=>'Fname', 'text_2'=>'Lname', 'father'=>$customerdetail['referral_id'], 'color'=>'#000');
            $GLOBALS['tree_data_levelsystem'][]=array('id'=>$id, 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>$customerdetail['referral_id'], 'color'=>'#16c9e5');
            
            
        }
//            echo "<pre>";
//            echo $callnumber;
//            var_dump($tree_plugindata);
//            echo $callnumber+1;
//            $GLOBALS['tree_data_levelsystem']=$tree_plugindata;
//            var_dump($GLOBALS['tree_data_levelsystem_'.$callnumber+1]);
//            exit;
        $mainarray=$subchildrens;
        }
        return $mainarray;
    }
    public function get_binary_childrens($customerid,$callnumber, $maximum_level){
        $binary_childs=$this->model_account_binarysystem->get_binary_childrens($customerid);
        $mainarray=array();
        
        $subchildrens=array();
        $tree_plugindata=array();
        
        foreach($binary_childs as $child){
            
            $customerdetail=$this->model_account_customer->getCustomer($child['customer_id']);
            if(!empty($customerdetail)){
                $sub_childs=$this->get_binary_childrens($child['customer_id'],"",$callnumber+1,$maximum_level);
                $subchildrens[]=array('id'=>$child['customer_id'], 'childs'=>$sub_childs);
                $GLOBALS['tree_data_binarysystem'][]=array('id'=>$child['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])),  'father'=>$customerdetail['binary_referral_id'], 'color'=>'#16c9e5');
            }else{
                $sub_childs=array();
                $subchildrens[]=array('id'=>$child['customer_id'], 'childs'=>$sub_childs);
                $GLOBALS['tree_data_binarysystem'][]=array('id'=>$child['customer_id'], 'text_1'=>"", 'text_2'=>'', 'text_id'=>'', 'text_joiningdate'=>'', 'father'=>$customerid, 'binary_position'=>$child['binary_position'], 'color'=>'#16c9e5');
            }
            
//            if($callnumber<$maximum_level){
//                $sub_childs=$this->get_binary_childrens($child['customer_id'],"",$callnumber+1,$maximum_level);
//            }else{
//                $sub_childs=array();
//            }
            
        }
        $mainarray=$subchildrens;
        
        return $mainarray;
    }
    public function calculate_left_points($childsarray,$levelpoints,$customerpoints,$divisiblepoints,$calculateuptolevels, $callnumber=1){
       if($callnumber>$calculateuptolevels){
            return $GLOBALS['left_points'];
        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        if(!empty($customerdetail)){
            if($customerdetail['cp_points']>=$divisiblepoints){
                $calculatedval=(int)($customerdetail['cp_points']/$divisiblepoints);
                $GLOBALS['left_points']=$GLOBALS['left_points']+$calculatedval;
            }
        }
        if($GLOBALS['left_points']>=$levelpoints){
            return $GLOBALS['left_points'];
        }else{
        if(!empty($childsarray['childs'])){
            foreach($childsarray['childs'] as $child){
                return $this->calculate_left_points($child,$levelpoints,$customerpoints,$divisiblepoints, $calculateuptolevels, $callnumber+1);
            }
        }
        
            return $GLOBALS['left_points'];
        }
    }
    
    public function calculate_right_points($childsarray,$levelpoints,$customerpoints,$divisiblepoints,$calculateuptolevels ,$callnumber=1){
        if($callnumber>$calculateuptolevels){
            return $GLOBALS['right_points'];
        }
//        echo "<pre>";
//        var_dump($childsarray);
//        if($GLOBALS['right_points']>=$levelpoints){
//            echo "in if";
//            exit;
//            return $GLOBALS['right_points'];
//        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
//        echo "<pre>";
//        var_dump($customerdetail);
//        echo $customerdetail['cp_points']." !!!!";
        if(!empty($customerdetail)){
            if($customerdetail['cp_points']>=$divisiblepoints){
                $calculatedval=(int)($customerdetail['cp_points']/$divisiblepoints);
                $GLOBALS['right_points']=$GLOBALS['right_points']+$calculatedval;
            }
        }
        
        if($GLOBALS['right_points']>=$levelpoints){
            return $GLOBALS['right_points'];
        }else{
        if(!empty($childsarray['childs'])){
            foreach($childsarray['childs'] as $child){
                $this->calculate_right_points($child,$levelpoints,$customerpoints,$divisiblepoints, $calculateuptolevels, $callnumber+1);
            }
        }
//            else{
//            return true;
//        }
        }
        return $GLOBALS['right_points'];
    }
    public function calculate_left_points_leadership($childsarray,$divisionby,$calculateuptolevels,$callnumber=1){
       if($callnumber>$calculateuptolevels){
            return $GLOBALS['left_points'];
        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        if(!empty($customerdetail)){
            if($customerdetail['cp_points']>=$divisionby){
                $calculatedval=(int)($customerdetail['cp_points']/$divisionby);
                $GLOBALS['left_points']=$GLOBALS['left_points']+$calculatedval;
            }
        }
        if(!empty($childsarray['childs'])){
            foreach($childsarray['childs'] as $child){
                $this->calculate_left_points_leadership($child,$divisionby,$calculateuptolevels,$callnumber+1);
            }
        }
        
            return $GLOBALS['left_points'];
    }
    
    public function calculate_right_points_leadership($childsarray,$divisionby,$calculateuptolevels,$callnumber=1){
        if($callnumber>$calculateuptolevels){
            return $GLOBALS['right_points'];
        }
//        if($GLOBALS['right_points']>=$levelpoints){
//            echo "in if";
//            exit;
//            return $GLOBALS['right_points'];
//        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        if(!empty($customerdetail)){
            if($customerdetail['cp_points']>=$divisionby){
                $calculatedval=(int)($customerdetail['cp_points']/$divisionby);
                $GLOBALS['right_points']=$GLOBALS['right_points']+$calculatedval;
            }
        }
        if(!empty($childsarray['childs'])){

            foreach($childsarray['childs'] as $child){
                $this->calculate_right_points_leadership($child,$divisionby,$calculateuptolevels,$callnumber+1);
            }
        }
        return $GLOBALS['right_points'];
    }
    public function findheight($leftchilds){
        $numberofnodes=sizeof($leftchilds);
        
        $remainingnodes=$numberofnodes;
        $depth=0;
        for($i=1;$i<=$numberofnodes;$i=($i*2)){
            $depth++;
            $remainingnodes=$remainingnodes-$i;
        }
        return $depth;
    }
    public function submitwithdrawal($customerdetail){
        if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
            if($this->request->post['withdrawal_type']=='ewallet'){
                if(!empty($customerdetail)){
                    $availableforwithdraw=$customerdetail['total_personal_earning']-$customerdetail['withdrawal_amount'];
                    if($this->request->post['withdrawal_amount']<=$availableforwithdraw){
                        if($this->model_account_customer->submit_withdrawal_ewallet($customerdetail)){
                            return true;
                        }
                    }
                    else{
                        $this->error['withdrawal_error']="Your withdrawal amount is greater than your personal earning!";
                        return !$this->error;
                    }
                }
            }
            elseif($this->request->post['withdrawal_type']!='ewallet'){
                if(!empty($customerdetail)){
                    $availableforwithdraw=$customerdetail['total_personal_earning']-$customerdetail['withdrawal_amount'];
                    if($this->request->post['withdrawal_amount']<=$availableforwithdraw){
                        if($this->model_account_customer->submit_withdrawal($customerdetail)){
                            return true;
                        }
                    }
                    else{
                        $this->error['withdrawal_error']="Your withdrawal amount is greater than your personal earning!";
                        return !$this->error;
                    }
                }
            }
        }
    }
}
