<?php
class ControllerAccountLeadershipbonus extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/account', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$this->load->model('account/binarysystem');
		$this->load->model('account/customer');
        $customer_id = $this->customer->getId();
        $customerdetail=$this->model_account_customer->getCustomer($customer_id);
		
        $mlm_settings=$this->model_account_binarysystem->get_binarysystem_settings();
        $leadershipsetting=$this->model_account_binarysystem->get_leaderaship_settings();
        $leadershipsteps=$this->model_account_binarysystem->get_leaderaship_steps();
        
        if($customerdetail['cp_points']<$leadershipsetting['eligibility_cp']){
            $data['eligibilty_error']="You are not eligible for leadership bonus.";
        }
        
        if(!empty($leadershipsetting)){
            $divisionby=$leadershipsetting['division_points'];
            $calculateuptolevels=$leadershipsetting['depth_level'];
        }else{
            $divisionby=0;
            $calculateuptolevels=0;
        }
//        if($customerdetail['cp_points']>=$mlm_settings['eligibility_cp']){
            
        
        if(isset($mlm_settings['maximum_level']) && $mlm_settings['maximum_level']!='' && $mlm_settings['maximum_level']!=0){
            $maximum_level=$mlm_settings['maximum_level'];
        }else{
            $maximum_level=0;
        }
        $GLOBALS['tree_data_binarysystem'][]=array('id'=>$customerdetail['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>null, 'color'=>'#16c9e5', 'leftaccount'=>'','rightaccount'=>'');
        $binarysystem=$this->get_binary_childrens($customer_id,1,$maximum_level);
        
//        echo "<pre>";
//        var_dump($binarysystem);
//        exit;
        $GLOBALS['left_accounts']=0;
        $GLOBALS['right_accounts']=0;
        $GLOBALS['left_points']=0;
        
        if(isset($binarysystem[0])){
            $GLOBALS['left_points']=$this->calculate_left_points($binarysystem[0],$divisionby,$calculateuptolevels);
        }
//        exit;
        $GLOBALS['right_points']=0;
        if(isset($binarysystem[1])){
            $GLOBALS['right_points']=$this->calculate_right_points($binarysystem[1],$divisionby,$calculateuptolevels);
        }
        if($GLOBALS['left_points']<=$GLOBALS['right_points']){
            $awarded_steps=$GLOBALS['left_points'];
        }
        else{
            $awarded_steps=$GLOBALS['right_points'];
        }
        $GLOBALS['tree_data_binarysystem'][0]['leftaccount']="Left Accounts: ".$GLOBALS['left_accounts'];
        $GLOBALS['tree_data_binarysystem'][0]['rightaccount']="Right Accounts: ".$GLOBALS['right_accounts'];
        $globalbonusvalues=0;
        $globalsteps=0;
        foreach($leadershipsteps as $step){
            $globalsteps=$globalsteps+$step['steps'];
            if($globalsteps<=$awarded_steps){
                $globalbonusvalues=$globalbonusvalues+$step['bonus_amount'];
            }
        }
        $data['plugin_tree_data']=$GLOBALS['tree_data_binarysystem'];
//        $bonusvalues=$this->model_account_binarysystem->get_leaderaship_bonus_againststeps($awarded_steps);
        
//        $leadershipbonus=0;
//        if(isset($bonusvalues['bonusamount']) && $bonusvalues['bonusamount']!=null){
//            $leadershipbonus=$bonusvalues['bonusamount'];
//        }
        $leadershipbonus=$globalbonusvalues;
        $data['leadershipbonus']=$leadershipbonus;
        $data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/leadershipbonus', $data));
	}
    public function get_binary_childrens($customerid,$callnumber, $maximum_level){
        $binary_childs=$this->model_account_binarysystem->get_binary_childrens($customerid);
        $mainarray=array();
        
        
        $subchildrens=array();
        $tree_plugindata=array();
        
        foreach($binary_childs as $child){
            
            $customerdetail=$this->model_account_customer->getCustomer($child['customer_id']);
            
            if(!empty($customerdetail)){
                if($callnumber<$maximum_level){
                    $sub_childs=$this->get_binary_childrens($child['customer_id'],"",$callnumber+1,$maximum_level);
                }else{
                    $sub_childs=array();
                }
                $subchildrens[]=array('id'=>$child['customer_id'], 'childs'=>$sub_childs);
                $GLOBALS['tree_data_binarysystem'][]=array('id'=>$child['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])),  'father'=>$customerdetail['binary_referral_id'], 'color'=>'#16c9e5', 'leftaccount'=>'','rightaccount'=>'');
            }else{
                $sub_childs=array();
                $subchildrens[]=array('id'=>$child['customer_id'], 'childs'=>$sub_childs);
                $GLOBALS['tree_data_binarysystem'][]=array('id'=>$child['customer_id'], 'text_1'=>"", 'text_2'=>'', 'text_id'=>'', 'text_joiningdate'=>'', 'father'=>$customerid, 'binary_position'=>$child['binary_position'], 'color'=>'#16c9e5', 'leftaccount'=>'','rightaccount'=>'');
            }
        }
        $mainarray=$subchildrens;
        
        return $mainarray;
    }
    public function calculate_left_points($childsarray,$divisionby,$calculateuptolevels,$callnumber=1){
        if($callnumber>$calculateuptolevels){
            return $GLOBALS['left_points'];
        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        if(!empty($customerdetail)){
            $GLOBALS['left_accounts']++;
            if($customerdetail['cp_points']>=$divisionby){
                $calculatedval=(int)($customerdetail['cp_points']/$divisionby);
                $GLOBALS['left_points']=$GLOBALS['left_points']+$calculatedval;
            }
        }
        if(!empty($childsarray['childs'])){
//            echo "<pre>";
//            var_dump($childsarray['childs']);
            foreach($childsarray['childs'] as $child){
                $this->calculate_left_points($child,$divisionby,$calculateuptolevels,$callnumber+1);
            }
        }
        
            return $GLOBALS['left_points'];
    }
    
    public function calculate_right_points($childsarray,$divisionby,$calculateuptolevels,$callnumber=1){
        
//        if($GLOBALS['right_points']>=$levelpoints){
//            echo "in if";
//            exit;
//            return $GLOBALS['right_points'];
//        }
        if($callnumber>$calculateuptolevels){
            return $GLOBALS['right_points'];
        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        if(!empty($customerdetail)){
            $GLOBALS['right_accounts']++;
            if($customerdetail['cp_points']>=$divisionby){
                $calculatedval=(int)($customerdetail['cp_points']/$divisionby);
                $GLOBALS['right_points']=$GLOBALS['right_points']+$calculatedval;
            }
        }
        if(!empty($childsarray['childs'])){

            foreach($childsarray['childs'] as $child){
                $this->calculate_right_points($child,$divisionby,$calculateuptolevels,$callnumber+1);
            }
        }
        return $GLOBALS['right_points'];
    }
}
