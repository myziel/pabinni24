<?php
class ControllerAccountSwitcherform extends Controller {
    private $error = array();
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/account', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}
        $this->load->model('account/customer');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $customer_id = $this->customer->getId();
            $customerdetail=$this->model_account_customer->getCustomer($customer_id);
            $sellerdetail=$this->model_account_customer->confirm_switch_to_seller($this->request->post,$customerdetail);
            
            if(!empty($sellerdetail)){
                $this->logout_customer();
                $this->response->redirect('seller/index.php?route=saccount/login&email='.$sellerdetail['email']);
            }
        }
        if (isset($this->error['referral_warning'])) {
			$data['error_referral_warning'] = $this->error['referral_warning'];
		} else {
			$data['error_referral_warning'] = '';
		}
        if (isset($this->error['binary_referral_warning'])) {
			$data['error_binary_referral_warning'] = $this->error['binary_referral_warning'];
		} else {
			$data['error_binary_referral_warning'] = '';
		}
        
        
        if (isset($this->request->post['referral_id'])) {
			$data['referral_id'] = $this->request->post['referral_id'];
		} else {
			$data['referral_id'] = '';
		}
        if (isset($this->request->post['binary_referral_id'])) {
			$data['binary_referral_id'] = $this->request->post['binary_referral_id'];
		} else {
			$data['binary_referral_id'] = '';
		}
        if (isset($this->request->post['binary_position'])) {
			$data['binary_position'] = $this->request->post['binary_position'];
		} else {
			$data['binary_position'] = '';
		}
        
        
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		
		$this->response->setOutput($this->load->view('account/switcher_form', $data));
	}
    public function logout_customer(){
        $this->customer->logout();
        
        unset($this->session->data['shipping_address']);
        unset($this->session->data['shipping_method']);
        unset($this->session->data['shipping_methods']);
        unset($this->session->data['payment_address']);
        unset($this->session->data['payment_method']);
        unset($this->session->data['payment_methods']);
        unset($this->session->data['comment']);
        unset($this->session->data['order_id']);
        unset($this->session->data['coupon']);
        unset($this->session->data['reward']);
        unset($this->session->data['voucher']);
        unset($this->session->data['vouchers']);
    }
	private function validate() {
        if($this->request->post['referral_id'] && $this->request->post['referral_id']!=''){
            
            $findreferralid=$this->model_account_customer->matchreferralidSeller($this->request->post['referral_id']);
            
            if(empty($findreferralid)){
                $this->error['referral_warning'] = 'Invalid Up Liner ID!';
            }
        }
        if($this->request->post['binary_referral_id'] && $this->request->post['binary_referral_id']!=''){
            
            $findreferralid=$this->model_account_customer->matchreferralidSeller($this->request->post['binary_referral_id']);
            if(empty($findreferralid)){
                $this->error['binary_referral_warning'] = 'Invalid Referral Id!';
            }
        }
		return !$this->error;
	}

}
