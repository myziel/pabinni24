<?php
class ControllerExtensionModuleCarousel extends Controller {
	public function index($setting) {
		static $module = 0;

		$this->load->model('design/banner');
		$this->load->model('tool/image');
        $this->load->language('product/category');
		$this->document->addStyle('catalog/view/javascript/jquery/owl-carousel/owl.carousel.css');
		$this->document->addScript('catalog/view/javascript/jquery/owl-carousel/owl.carousel.min.js');

		$data['banners'] = array();

		$results = $this->model_design_banner->getBanner($setting['banner_id']);

		foreach ($results as $result) {
			if (is_file(DIR_IMAGE . $result['image'])) {
				$data['banners'][] = array(
					'title' => $result['title'],
					'link'  => $result['link'],
					'image' => $this->model_tool_image->resize($result['image'], $setting['width'], $setting['height'])
				);
			}
		}

		$data['module'] = $module++;
        
        $this->load->model('catalog/category');
        $this->load->model('catalog/product');
        $data['categories'] = array();

		$categories = $this->model_catalog_category->getCategories(0);

		foreach ($categories as $category) {
			if ($category['top']) {
				// Level 2
				$children_data = array();

				$children = $this->model_catalog_category->getCategories($category['category_id']);

				foreach ($children as $child) {
					$filter_data = array(
						'filter_category_id'  => $child['category_id'],
						'filter_sub_category' => true
					);

					$children_data[] = array(
						'name'  => $child['name'] . ($this->config->get('config_product_count') ? ' (' . $this->model_catalog_product->getTotalProducts($filter_data) . ')' : ''),
						'href'  => $this->url->link('product/category', 'path=' . $category['category_id'] . '_' . $child['category_id'])
					);
				}

				// Level 1
				$data['categories'][] = array(
					'name'     => $category['name'],
					'children' => $children_data,
					'column'   => $category['column'] ? $category['column'] : 1,
					'href'     => $this->url->link('product/category', 'path=' . $category['category_id'])
				);
			}
		}
        
        /* Latest Products Code Start */
        
        $latestproducts = $this->model_catalog_product->getLatestProducts(12);
        $data['latestproducts']=array();
        $data['text_tax'] = $this->language->get('text_tax');
        foreach ($latestproducts as $result) {
				if ($result['image']) {
					$image = $this->model_tool_image->resize($result['image'], $this->config->get($this->config->get('config_theme') . '_image_product_width'), $this->config->get($this->config->get('config_theme') . '_image_product_height'));
				} else {
					$image = $this->model_tool_image->resize('placeholder.png', $this->config->get($this->config->get('config_theme') . '_image_product_width'), $this->config->get($this->config->get('config_theme') . '_image_product_height'));
				}

				if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
					$price = $this->currency->format($this->tax->calculate($result['price'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$price = false;
				}

				if ((float)$result['special']) {
					$special = $this->currency->format($this->tax->calculate($result['special'], $result['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
				} else {
					$special = false;
				}

				if ($this->config->get('config_tax')) {
					$tax = $this->currency->format((float)$result['special'] ? $result['special'] : $result['price'], $this->session->data['currency']);
				} else {
					$tax = false;
				}

				if ($this->config->get('config_review_status')) {
					$rating = (int)$result['rating'];
				} else {
					$rating = false;
				}
                
                
                
                $cptext="";
                
                if($special){
                    $cppassprice=$result['special'];
                }
                else{
                    $cppassprice=$result['price'];
                }
                if($result['buyer_percentage']!=0){
                    $amounttobuyer=($cppassprice*$result['buyer_percentage'])/100;
                    $cpvalue=convert_amount_to_cp($amounttobuyer,$this->config->get('cp_point_amount'));
                    
                    $cptext="(CP Value: ".$cpvalue.")";
                }elseif($result['buyer_direct_amount']!=0){
                    $cpvalue=convert_amount_to_cp($result['buyer_direct_amount'],$this->config->get('cp_point_amount'));
                    $cptext="(CP Value: ".$cpvalue.")";
                }
				$data['latestproducts'][] = array(
					'product_id'  => $result['product_id'],
					'cp_text'  => $cptext,
					'thumb'       => $image,
					'name'        => $result['name'],
					'description' => utf8_substr(strip_tags(html_entity_decode($result['description'], ENT_QUOTES, 'UTF-8')), 0, $this->config->get($this->config->get('config_theme') . '_product_description_length')) . '..',
					'price'       => $price,
					'special'     => $special,
					'tax'         => $tax,
					'minimum'     => $result['minimum'] > 0 ? $result['minimum'] : 1,
					'rating'      => $result['rating'],
					'href'        => $this->url->link('product/product', 'product_id=' . $result['product_id'] )
				);
			}
        
        /* Latest Products Code End */
        
        
        $this->load->model('catalog/information');
        $welcome_content = $this->model_catalog_information->getInformation(7);
        $data['welcome_content']=$welcome_content;
        $data['welcome_content']['description'] = html_entity_decode($data['welcome_content']['description'], ENT_QUOTES, 'UTF-8');
        $data['welcome_content']['href']=$this->url->link('information/information', 'information_id=' . 7);
		return $this->load->view('extension/module/carousel', $data);
	}
}