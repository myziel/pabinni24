<?php
class ControllerAccountBinarysystem extends Controller {
	public function index() {
		if (!$this->customer->isLogged()) {
			$this->session->data['redirect'] = $this->url->link('account/account', '', true);

			$this->response->redirect($this->url->link('account/login', '', true));
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		$this->load->model('account/binarysystem');
		$this->load->model('account/customer');
        $customer_id = $this->customer->getId();
        $customerdetail=$this->model_account_customer->getCustomer($customer_id);
		
        $mlm_settings=$this->model_account_binarysystem->get_binarysystem_settings();
//        if($customerdetail['cp_points']>=$mlm_settings['eligibility_cp']){
            
        
        if(isset($mlm_settings['maximum_level']) && $mlm_settings['maximum_level']!='' && $mlm_settings['maximum_level']!=0){
            $maximum_level=$mlm_settings['maximum_level'];
        }else{
            $maximum_level=0;
        }
        $GLOBALS['tree_data_binarysystem'][]=array('id'=>$customerdetail['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])), 'father'=>null, 'color'=>'#16c9e5', 'leftaccount'=>'','rightaccount'=>'');
        $binarysystem=$this->get_binary_childrens($customer_id,1,$maximum_level);
        
        $levelpoints=0;
        $calculateuptolevels=0;
        if($mlm_settings['level_points'] && $mlm_settings['level_points']!=''){
            $unlocklevels=unserialize($mlm_settings['level_points']);
            $temppreviouspoints=0;
            for($i=1;$i<=sizeof($unlocklevels);$i++){
                if(isset($unlocklevels[$i])){
                    if($customerdetail['cp_points']>=$unlocklevels[$i]['eligibility_level_points'] && $customerdetail['cp_points']>$temppreviouspoints){
                        
                        $levelpoints=$unlocklevels[$i]['eligibility_steps'];
                        $calculateuptolevels=$unlocklevels[$i]['calculated_steps'];
//                        $divisiblepoints=$unlocklevels[$i]['eligibility_level_points'];
                        $temppreviouspoints=$unlocklevels[$i]['eligibility_level_points'];
                    }
                }
                
            }
        }else{
            $levelpoints=0;
        }
        $divisiblepoints=$mlm_settings['eligibility_cp'];
        $GLOBALS['left_points']=0;
        $GLOBALS['left_accounts']=0;
        $GLOBALS['right_accounts']=0;
        
        
        if(isset($binarysystem[0])){
            $GLOBALS['left_points']=$this->calculate_left_points($binarysystem[0],$levelpoints,$customerdetail['cp_points'],$divisiblepoints,$calculateuptolevels);
        }
        $GLOBALS['right_points']=0;
        if(isset($binarysystem[1])){
            $GLOBALS['right_points']=$this->calculate_right_points($binarysystem[1],$levelpoints,$customerdetail['cp_points'],$divisiblepoints,$calculateuptolevels);
        }
        if($GLOBALS['right_points']>=$levelpoints){
            $GLOBALS['right_points']=$levelpoints;
        }
        if($GLOBALS['left_points']>=$levelpoints){
            $GLOBALS['left_points']=$levelpoints;
        }
        if($GLOBALS['left_points']<$GLOBALS['right_points']){
            $totalcppoints=$mlm_settings['step_value']*$GLOBALS['left_points'];
        }
        else{
            $totalcppoints=$mlm_settings['step_value']*$GLOBALS['right_points'];
        }
        
        $GLOBALS['tree_data_binarysystem'][0]['leftaccount']="Left Accounts: ".$GLOBALS['left_accounts'];
        $GLOBALS['tree_data_binarysystem'][0]['rightaccount']="Right Accounts: ".$GLOBALS['right_accounts'];
        
        $data['left_accounts']=$GLOBALS['left_accounts'];
        $data['right_accounts']=$GLOBALS['right_accounts'];
        $data['plugin_tree_data']=$GLOBALS['tree_data_binarysystem'];
        $data['register_url']=$this->url->link('account/register');
        $data['total_cp_points']=$totalcppoints;
//        }else{
//            $data['eligibilty_error']="You are not eligible for binary system.";
//        }
        $data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		$this->response->setOutput($this->load->view('account/binarysystem', $data));
	}
    public function get_binary_childrens($customerid,$callnumber, $maximum_level){
        $binary_childs=$this->model_account_binarysystem->get_binary_childrens($customerid);
        $mainarray=array();
        
        $subchildrens=array();
        $tree_plugindata=array();
        
        foreach($binary_childs as $child){
            
            $customerdetail=$this->model_account_customer->getCustomer($child['customer_id']);
            if(!empty($customerdetail)){
                $sub_childs=$this->get_binary_childrens($child['customer_id'],"",$callnumber+1,$maximum_level);
                $subchildrens[]=array('id'=>$child['customer_id'], 'childs'=>$sub_childs);
                $GLOBALS['tree_data_binarysystem'][]=array('id'=>$child['customer_id'], 'text_1'=>$customerdetail['firstname']." ".$customerdetail['lastname'], 'text_2'=>'CP Points: '.$customerdetail['cp_points'], 'text_id' => 'ID: '.$customerdetail['customer_id'], 'text_joiningdate' => 'Joining Date: '.date('d-M-Y',strtotime($customerdetail['date_added'])),  'father'=>$customerdetail['binary_referral_id'], 'color'=>'#16c9e5', 'leftaccount'=>'','rightaccount'=>'');
            }else{
                $sub_childs=array();
                $subchildrens[]=array('id'=>$child['customer_id'], 'childs'=>$sub_childs);
                $GLOBALS['tree_data_binarysystem'][]=array('id'=>$child['customer_id'], 'text_1'=>"", 'text_2'=>'', 'text_id'=>'', 'text_joiningdate'=>'', 'father'=>$customerid, 'binary_position'=>$child['binary_position'], 'color'=>'#16c9e5', 'leftaccount'=>'','rightaccount'=>'');
            }
            
//            if($callnumber<$maximum_level){
//                $sub_childs=$this->get_binary_childrens($child['customer_id'],"",$callnumber+1,$maximum_level);
//            }else{
//                $sub_childs=array();
//            }
            
        }
        $mainarray=$subchildrens;
        
        return $mainarray;
    }
    public function calculate_left_points($childsarray,$levelpoints,$customerpoints,$divisiblepoints,$calculateuptolevels, $callnumber=1){
        if($callnumber>$calculateuptolevels){
            return $GLOBALS['left_points'];
        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
        if(!empty($customerdetail)){
            $GLOBALS['left_accounts']++;
            if($customerdetail['cp_points']>=$divisiblepoints){
                $calculatedval=(int)($customerdetail['cp_points']/$divisiblepoints);
                $GLOBALS['left_points']=$GLOBALS['left_points']+$calculatedval;
            }
        }
        if($GLOBALS['left_points']>=$levelpoints){
            return $GLOBALS['left_points'];
        }else{
        if(!empty($childsarray['childs'])){
            foreach($childsarray['childs'] as $child){
                return $this->calculate_left_points($child,$levelpoints,$customerpoints,$divisiblepoints,$calculateuptolevels, $callnumber+1);
            }
        }
        
            return $GLOBALS['left_points'];
        }
    }
    
    public function calculate_right_points($childsarray,$levelpoints,$customerpoints,$divisiblepoints,$calculateuptolevels,$callnumber=1){
        
//        echo "<pre>";
//        var_dump($childsarray);
//        if($GLOBALS['right_points']>=$levelpoints){
//            echo "in if";
//            exit;
//            return $GLOBALS['right_points'];
//        }
        if($callnumber>$calculateuptolevels){
            return $GLOBALS['right_points'];
        }
        $customerdetail=$this->model_account_customer->getCustomer($childsarray['id']);
//        echo "<pre>";
//        var_dump($customerdetail);
//        echo $customerdetail['cp_points']." !!!!";
        if(!empty($customerdetail)){
            $GLOBALS['right_accounts']++;
            if($customerdetail['cp_points']>=$divisiblepoints){
                $calculatedval=(int)($customerdetail['cp_points']/$divisiblepoints);
                $GLOBALS['right_points']=$GLOBALS['right_points']+$calculatedval;
            }
        }
        
        if($GLOBALS['right_points']>=$levelpoints){
            return $GLOBALS['right_points'];
        }else{
        if(!empty($childsarray['childs'])){
            foreach($childsarray['childs'] as $child){
                $this->calculate_right_points($child,$levelpoints,$customerpoints,$divisiblepoints,$calculateuptolevels,$callnumber+1);
            }
        }
//            else{
//            return true;
//        }
        }
        return $GLOBALS['right_points'];
    }
}
