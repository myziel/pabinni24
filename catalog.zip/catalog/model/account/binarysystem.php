<?php
class ModelAccountBinarysystem extends Model {
    
    
    public function get_binary_childrens($customer_id){
        
        $query = $this->db->query("SELECT customer_id, binary_position FROM " . DB_PREFIX . "customer WHERE binary_referral_id = '" . (int)$customer_id . "' ORDER BY binary_position ASC");
		$binarychilds=$query->rows;
        
        if(sizeof($binarychilds)==2){
            return $binarychilds;
        }elseif(sizeof($binarychilds)==1){
            $subarray=array();
            if($binarychilds[0]['binary_position']==0){
                $subarray[0]=$binarychilds[0];
                $subarray[1]=array(
                    'customer_id' => 0,
                    'binary_position' => 1
                );
            }
            elseif($binarychilds[0]['binary_position']==1){
                $subarray[0]=array(
                    'customer_id' => 0,
                    'binary_position' => 0
                );
                $subarray[1]=$binarychilds[0];
                
            }
            
            return $subarray;
        }else{
            return $binarychilds;
        }
    }
    public function get_cppoint_value_indollar(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE setting_id = 292");
		return $query->row;
    }
    public function get_binarysystem_settings(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "mlm_settings WHERE id = 2");
		return $query->row;
    }
    public function get_leaderaship_settings(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "mlm_settings WHERE id = 3");
		return $query->row;
    }
    public function get_autonetbalancing_settings(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "mlm_settings WHERE id = 4");
		return $query->row;
    }
    public function get_leaderaship_bonus_againststeps($awarded_steps){
        $query = $this->db->query("SELECT MAX(bonus_amount) as bonusamount FROM " . DB_PREFIX . "leadership_levels WHERE steps <= '".(int)$awarded_steps."' AND setting_type=1");
		return $query->row;
    }
    
    public function get_leaderaship_steps(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "leadership_levels WHERE setting_type=1");
		return $query->rows;
    }
    public function get_autonetbalancing_bonus_againststeps($awarded_steps){
        $query = $this->db->query("SELECT MAX(bonus_amount) as bonusamount FROM " . DB_PREFIX . "autonetbalancing_levels WHERE steps <= '".(int)$awarded_steps."' AND setting_type = 1");
		return $query->row;
    }
    public function get_autonetbalancing_bonus_steps(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "autonetbalancing_levels WHERE setting_type = 1");
		return $query->rows;
    }
    public function get_qualified_customers($customer_id){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "autonetbalancing_qualifications WHERE id >= (SELECT id FROM ".DB_PREFIX."autonetbalancing_qualifications WHERE customer_id ='".(int)$customer_id."')");
		return $query->rows;
    }
}
