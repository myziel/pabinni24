<?php
class ModelAccountLevelsystem extends Model {
    
    
    public function get_first_level($customer_id){
        $query = $this->db->query("SELECT first_levels FROM " . DB_PREFIX . "customer WHERE customer_id = '" . (int)$customer_id . "'");
		return $query->row;
    }
    public function get_levelsystem_settings(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "mlm_settings WHERE id = 1");
		return $query->row;
    }
    public function get_system_percentages(){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "system_percentages");
		return $query->row;
    }
}
