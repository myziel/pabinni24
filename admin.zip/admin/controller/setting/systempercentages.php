<?php
class ControllerSettingSystempercentages extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('setting/mlmsettings');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/binarysettings');

		$this->getList();
	}
    protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, true)
		);

		$data['add'] = $this->url->link('catalog/category/add', 'token=' . $this->session->data['token'] . $url, true);
		$data['delete'] = $this->url->link('catalog/category/delete', 'token=' . $this->session->data['token'] . $url, true);
		$data['repair'] = $this->url->link('catalog/category/repair', 'token=' . $this->session->data['token'] . $url, true);

		$data['settings'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$settings_total = $this->model_setting_binarysettings->getTotalSettings();

		$results = $this->model_setting_mlmsettings->getSettings($filter_data);

        $flag=0;
        foreach($results as $result){
            $data['settings'][]=$result;
            if($result['id']==1){
                $data['settings'][$flag]['edit']=$this->url->link('setting/mlmsettings/edit', 'token=' . $this->session->data['token'] . '&setting_id=' . $result['id'] . $url, true);
            }
            elseif($result['id']==2){
                $data['settings'][$flag]['edit']=$this->url->link('setting/binarysettings/edit', 'token=' . $this->session->data['token'] . '&setting_id=' . $result['id'] . $url, true);
            }
            $flag++;
        }

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');

		$data['column_name'] = $this->language->get('column_name');
		$data['column_maximum_levels'] = $this->language->get('column_maximum_levels');
		$data['column_action'] = $this->language->get('column_action');

		$data['button_add'] = $this->language->get('button_add');
		$data['button_edit'] = $this->language->get('button_edit');
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_rebuild'] = $this->language->get('button_rebuild');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('catalog/category', 'token=' . $this->session->data['token'] . '&sort=name' . $url, true);
		$data['sort_sort_order'] = $this->url->link('catalog/category', 'token=' . $this->session->data['token'] . '&sort=sort_order' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $settings_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($settings_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($settings_total - $this->config->get('config_limit_admin'))) ? $settings_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $settings_total, ceil($settings_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('setting/mlmsettings_list', $data));
	}
    
    public function edit() {
		$this->load->language('setting/mlmsettings');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/mlmsettings');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_setting_mlmsettings->editSetting_systempercentages($this->request->get['setting_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
            if (isset($this->request->get['setting_type'])) {
			 $url .= '&setting_type=' . $this->request->get['setting_type'];
		  }
			$this->response->redirect($this->url->link('setting/systempercentages/edit', 'token=' . $this->session->data['token'] . $url."&setting_id=".$this->request->get['setting_id'], true));
		}

		$this->getForm();
	}

    protected function getForm() {
		$data['heading_title'] = "System Percentages";

		$data['text_form'] = !isset($this->request->get['setting_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['text_none'] = $this->language->get('text_none');
		$data['text_default'] = $this->language->get('text_default');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_maximumlevel'] = $this->language->get('entry_maximumlevel');
		$data['entry_poinpercentage'] = $this->language->get('entry_poinpercentage');
		$data['entry_levelpoints'] = $this->language->get('entry_levelpoints');

		$data['help_filter'] = $this->language->get('help_filter');
		$data['help_keyword'] = $this->language->get('help_keyword');
		$data['help_top'] = $this->language->get('help_top');
		$data['help_column'] = $this->language->get('help_column');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['tab_general'] = $this->language->get('tab_general');
		$data['tab_data'] = $this->language->get('tab_data');
		$data['tab_design'] = $this->language->get('tab_design');
		$data['setting_type'] = $this->request->get['setting_type'];

        if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
        
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = array();
		}
		if (isset($this->error['percentage_error'])) {
			$data['error_percentage_error'] = $this->error['percentage_error'];
		} else {
			$data['error_percentage_error'] = '';
		}
        if (isset($this->error['percentage_error2'])) {
			$data['error_percentage_error2'] = $this->error['percentage_error2'];
		} else {
			$data['error_percentage_error2'] = '';
		}
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}
		if (isset($this->request->get['setting_type'])) {
			$url .= '&setting_type=' . $this->request->get['setting_type'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		if(isset($this->request->get['setting_type']) && $this->request->get['setting_type']==1){
            $data['breadcrumbs'][] = array(
			     'text' => "Consumer Settings",
			     'href' => ""
		      );
        }else if(isset($this->request->get['setting_type']) && $this->request->get['setting_type']==2){
            $data['breadcrumbs'][] = array(
			     'text' => "Vendors Settings",
			     'href' => ""
		      );
        }
        else if(isset($this->request->get['setting_type']) && $this->request->get['setting_type']==3){
            $data['breadcrumbs'][] = array(
			     'text' => "Franchises Settings",
			     'href' => ""
		      );
        }
        

		$data['breadcrumbs'][] = array(
			'text' => "System Percentages",
			'href' => ""
		);

		if (!isset($this->request->get['setting_id'])) {
			$data['action'] = $this->url->link('setting/systempercentages/add', 'token=' . $this->session->data['token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('setting/systempercentages/edit', 'token=' . $this->session->data['token'] . '&setting_id=' . $this->request->get['setting_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('setting/mlmsettings', 'token=' . $this->session->data['token'] . $url, true);

		if (isset($this->request->get['setting_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$setting_info = $this->model_setting_mlmsettings->getSetting($this->request->get['setting_id']);
            $system_percentages=$this->model_setting_mlmsettings->get_system_percentages();
		}
		$data['token'] = $this->session->data['token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
        
        if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} elseif (!empty($setting_info)) {
			$data['name'] = $setting_info['name'];
		} else {
			$data['name'] = '';
		}
        
        if (isset($this->request->post['admin_expense'])) {
			$data['admin_expense'] = $this->request->post['admin_expense'];
		} elseif (!empty($system_percentages)) {
			$data['admin_expense'] = $system_percentages['admin_expense'];
		} else {
			$data['admin_expense'] = '';
		}
        
        if (isset($this->request->post['vendors_expense'])) {
			$data['vendors_expense'] = $this->request->post['vendors_expense'];
		} elseif (!empty($system_percentages)) {
			$data['vendors_expense'] = $system_percentages['vendors_expense'];
		} else {
			$data['vendors_expense'] = '';
		}
        
        if (isset($this->request->post['frenchises_expense'])) {
			$data['frenchises_expense'] = $this->request->post['frenchises_expense'];
		} elseif (!empty($system_percentages)) {
			$data['frenchises_expense'] = $system_percentages['frenchises_expense'];
		} else {
			$data['frenchises_expense'] = '';
		}
        
        if (isset($this->request->post['customer_expense'])) {
			$data['customer_expense'] = $this->request->post['customer_expense'];
		} elseif (!empty($system_percentages)) {
			$data['customer_expense'] = $system_percentages['customer_expense'];
		} else {
			$data['customer_expense'] = '';
		}
        
        if (isset($this->request->post['personal_points'])) {
			$data['personal_points'] = $this->request->post['personal_points'];
		} elseif (!empty($system_percentages)) {
			$data['personal_points'] = $system_percentages['personal_points'];
		} else {
			$data['personal_points'] = '';
		}
        
        
        if (isset($this->request->post['level_system'])) {
			$data['level_system'] = $this->request->post['level_system'];
		} elseif (!empty($system_percentages)) {
			$data['level_system'] = $system_percentages['level_system'];
		} else {
			$data['level_system'] = '';
		}
        
        if (isset($this->request->post['binary_system'])) {
			$data['binary_system'] = $this->request->post['binary_system'];
		} elseif (!empty($system_percentages)) {
			$data['binary_system'] = $system_percentages['binary_system'];
		} else {
			$data['binary_system'] = '';
		}
        
        if (isset($this->request->post['leadership_system'])) {
			$data['leadership_system'] = $this->request->post['leadership_system'];
		} elseif (!empty($system_percentages)) {
			$data['leadership_system'] = $system_percentages['leadership_system'];
		} else {
			$data['leadership_system'] = '';
		}
        
        if (isset($this->request->post['autonet_system'])) {
			$data['autonet_system'] = $this->request->post['autonet_system'];
		} elseif (!empty($system_percentages)) {
			$data['autonet_system'] = $system_percentages['autonet_system'];
		} else {
			$data['autonet_system'] = '';
		}
        
        
        if (isset($this->request->post['personal_points_franchise'])) {
			$data['personal_points_franchise'] = $this->request->post['personal_points_franchise'];
		} elseif (!empty($system_percentages)) {
			$data['personal_points_franchise'] = $system_percentages['personal_points_franchise'];
		} else {
			$data['personal_points_franchise'] = '';
		}
        if (isset($this->request->post['level_system_franchise'])) {
			$data['level_system_franchise'] = $this->request->post['level_system_franchise'];
		} elseif (!empty($system_percentages)) {
			$data['level_system_franchise'] = $system_percentages['level_system_franchise'];
		} else {
			$data['level_system_franchise'] = '';
		}
        
        if (isset($this->request->post['binary_system_franchise'])) {
			$data['binary_system_franchise'] = $this->request->post['binary_system_franchise'];
		} elseif (!empty($system_percentages)) {
			$data['binary_system_franchise'] = $system_percentages['binary_system_franchise'];
		} else {
			$data['binary_system_franchise'] = '';
		}
        
        if (isset($this->request->post['leadership_system_franchise'])) {
			$data['leadership_system_franchise'] = $this->request->post['leadership_system_franchise'];
		} elseif (!empty($system_percentages)) {
			$data['leadership_system_franchise'] = $system_percentages['leadership_system_franchise'];
		} else {
			$data['leadership_system_franchise'] = '';
		}
        
        if (isset($this->request->post['autonet_system_franchise'])) {
			$data['autonet_system_franchise'] = $this->request->post['autonet_system_franchise'];
		} elseif (!empty($system_percentages)) {
			$data['autonet_system_franchise'] = $system_percentages['autonet_system_franchise'];
		} else {
			$data['autonet_system_franchise'] = '';
		}
        
        
        if (isset($this->request->post['personal_points_vendor'])) {
			$data['personal_points_vendor'] = $this->request->post['personal_points_vendor'];
		} elseif (!empty($system_percentages)) {
			$data['personal_points_vendor'] = $system_percentages['personal_points_vendor'];
		} else {
			$data['personal_points_vendor'] = '';
		}
        if (isset($this->request->post['level_system_vendor'])) {
			$data['level_system_vendor'] = $this->request->post['level_system_vendor'];
		} elseif (!empty($system_percentages)) {
			$data['level_system_vendor'] = $system_percentages['level_system_vendor'];
		} else {
			$data['level_system_vendor'] = '';
		}
        
        if (isset($this->request->post['binary_system_vendor'])) {
			$data['binary_system_vendor'] = $this->request->post['binary_system_vendor'];
		} elseif (!empty($system_percentages)) {
			$data['binary_system_vendor'] = $system_percentages['binary_system_vendor'];
		} else {
			$data['binary_system_vendor'] = '';
		}
        
        if (isset($this->request->post['leadership_system_vendor'])) {
			$data['leadership_system_vendor'] = $this->request->post['leadership_system_vendor'];
		} elseif (!empty($system_percentages)) {
			$data['leadership_system_vendor'] = $system_percentages['leadership_system_vendor'];
		} else {
			$data['leadership_system_vendor'] = '';
		}
        
        if (isset($this->request->post['autonet_system_vendor'])) {
			$data['autonet_system_vendor'] = $this->request->post['autonet_system_vendor'];
		} elseif (!empty($system_percentages)) {
			$data['autonet_system_vendor'] = $system_percentages['autonet_system_vendor'];
		} else {
			$data['autonet_system_vendor'] = '';
		}
        
        
        
		$this->load->model('design/layout');

		$data['layouts'] = $this->model_design_layout->getLayouts();

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('setting/systempercentages_form', $data));
	}

    protected function validateForm() {
        
        $totalpercentage=0;
        if(isset($this->request->post['admin_expense'])){
            $totalpercentage=$totalpercentage+$this->request->post['admin_expense'];
        }
        if(isset($this->request->post['vendors_expense'])){
            $totalpercentage=$totalpercentage+$this->request->post['vendors_expense'];
        }
        if(isset($this->request->post['frenchises_expense'])){
            $totalpercentage=$totalpercentage+$this->request->post['frenchises_expense'];
        }
        if(isset($this->request->post['customer_expense'])){
            $totalpercentage=$totalpercentage+$this->request->post['customer_expense'];
        }
        if($totalpercentage!=100){
            $this->error['percentage_error'] = 'Total of the percentages must equal to 100!';
        }
        if($this->request->get['setting_type']==1){
            $totalpercentage2=0;
            if(isset($this->request->post['level_system'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['level_system'];
            }
            if(isset($this->request->post['binary_system'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['binary_system'];
            }
            if(isset($this->request->post['leadership_system'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['leadership_system'];
            }
            if(isset($this->request->post['autonet_system'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['autonet_system'];
            }
            if(isset($this->request->post['personal_points'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['personal_points'];
            }
            if($totalpercentage2!=100){
                $this->error['percentage_error2'] = 'Total of the percentages must equal to 100!';
            }
        }
        else if($this->request->get['setting_type']==2){
            $totalpercentage2=0;
            if(isset($this->request->post['level_system_vendor'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['level_system_vendor'];
            }
            if(isset($this->request->post['binary_system_vendor'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['binary_system_vendor'];
            }
            if(isset($this->request->post['leadership_system_vendor'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['leadership_system_vendor'];
            }
            if(isset($this->request->post['autonet_system_vendor'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['autonet_system_vendor'];
            }
            if(isset($this->request->post['personal_points_vendor'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['personal_points_vendor'];
            }
            if($totalpercentage2!=100){
                $this->error['percentage_error2'] = 'Total of the percentages must equal to 100!';
            }
        }
        
        else if($this->request->get['setting_type']==3){
            $totalpercentage2=0;
            if(isset($this->request->post['level_system_franchise'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['level_system_franchise'];
            }
            if(isset($this->request->post['binary_system_franchise'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['binary_system_franchise'];
            }
            if(isset($this->request->post['leadership_system_franchise'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['leadership_system_franchise'];
            }
            if(isset($this->request->post['autonet_system_franchise'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['autonet_system_franchise'];
            }
            if(isset($this->request->post['personal_points_franchise'])){
                $totalpercentage2=$totalpercentage2+$this->request->post['personal_points_franchise'];
            }
            if($totalpercentage2!=100){
                $this->error['percentage_error2'] = 'Total of the percentages must equal to 100!';
            }
        }
        
		return !$this->error;
	}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
	public function add() {
		$this->load->language('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/category');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_catalog_category->addCategory($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, true));
		}

		$this->getForm();
	}

	
	public function delete() {
		$this->load->language('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/category');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $category_id) {
				$this->model_catalog_category->deleteCategory($category_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, true));
		}

		$this->getList();
	}

	public function repair() {
		$this->load->language('catalog/category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('catalog/category');

		if ($this->validateRepair()) {
			$this->model_catalog_category->repairCategories();

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('catalog/category', 'token=' . $this->session->data['token'] . $url, true));
		}

		$this->getList();
	}

	

	
	

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'catalog/category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	protected function validateRepair() {
		if (!$this->user->hasPermission('modify', 'catalog/category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_name'])) {
			$this->load->model('catalog/category');

			$filter_data = array(
				'filter_name' => $this->request->get['filter_name'],
				'sort'        => 'name',
				'order'       => 'ASC',
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_catalog_category->getCategories($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'category_id' => $result['category_id'],
					'name'        => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8'))
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['name'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
