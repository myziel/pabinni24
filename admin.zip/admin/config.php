<?php
// HTTP
define('HTTP_SERVER', 'http://myziel.com/admin/');
define('HTTP_CATALOG', 'http://myziel.com/');

// HTTPS
define('HTTPS_SERVER', 'http://myziel.com/admin/');
define('HTTPS_CATALOG', 'http://myziel.com/');

// DIR
define('DIR_APPLICATION', '/home/abziel/public_html/admin/');
define('DIR_SYSTEM', '/home/abziel/public_html/system/');
define('DIR_IMAGE', '/home/abziel/public_html/image/');
define('DIR_LANGUAGE', '/home/abziel/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/abziel/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/abziel/public_html/system/config/');
define('DIR_CACHE', '/home/abziel/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/abziel/public_html/system/storage/download/');
define('DIR_LOGS', '/home/abziel/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/abziel/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/abziel/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/abziel/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'abziel_developer');
define('DB_PASSWORD', 'Welcome@Myziel123');
define('DB_DATABASE', 'abziel_abaska');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
